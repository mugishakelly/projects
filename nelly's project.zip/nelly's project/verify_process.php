<?php
include "config/config.php";

// Function to generate random verification code
function generateVerificationCode($length = 6) {
    return substr(str_shuffle("0123456789"), 0, $length);
}

// Function to send verification email
function sendVerificationEmail($email, $firstname, $verificationCode) {
    $subject = "Verify AGRIVISTA Account";
    
    $message = "
    <html>
    <head>
        <title>Email Verification</title>
    </head>
    <body>
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;'>
            <h2 style='color: #4CAF50;'>Welcome to Agro Tourism, $firstname!</h2>
            <p>Thank you for registering with us. To complete your registration, please use the verification code below:</p>
            <div style='background-color: #f9f9f9; padding: 15px; text-align: center; font-size: 24px; letter-spacing: 5px; font-weight: bold; margin: 20px 0;'>
                $verificationCode
            </div>
            <p>This code will expire in 24 hours.</p>
            <p>If you did not create an account, please ignore this email.</p>
            <p>Best regards,<br>The AGRIVISTA Team</p>
        </div>
    </body>
    </html>
    ";
    
    // Headers for HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: noreply@agrotourism.com" . "\r\n";
    
    // Send email
    return mail($email, $subject, $message, $headers);
}

// Check if email is stored in session
if (!isset($_SESSION['temp_email'])) {
    // Redirect to registration page if no email is found
    header("Location: signup.php");
    exit();
}

$email = $_SESSION['temp_email'];

// Process verification code
if (isset($_POST['verify'])) {
    $verification_code = mysqli_real_escape_string($conn, $_POST['verification_code']);
    
    // Check if verification code is valid
    $sql = "SELECT * FROM customer WHERE email='$email' AND verification_code='$verification_code' AND verification_expiry > NOW()";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        // Update verification status
        $update_sql = "UPDATE customer SET is_verified=1 WHERE email='$email'";
        if (mysqli_query($conn, $update_sql)) {
            // Clear session
            unset($_SESSION['temp_email']);
            
            echo "<script>alert('Email verified successfully! You can now login.');</script>";
            echo "<script>window.location.href = 'index.php';</script>";
        } else {
            echo "<script>alert('Error updating verification status. Please try again.');</script>";
            echo "<script>window.location.href = 'verify.php';</script>";
        }
    } else {
        echo "<script>alert('Invalid or expired verification code.');</script>";
        echo "<script>window.location.href = 'verify.php';</script>";
    }
}

// Resend verification code
if (isset($_POST['resend_code'])) {
    // Get user details
    $sql = "SELECT first_name FROM customer WHERE email='$email'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $firstname = $row['first_name'];
        
        // Generate new verification code
        $verification_code = generateVerificationCode();
        $verification_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        // Update verification code in database
        $update_sql = "UPDATE customer SET verification_code='$verification_code', verification_expiry='$verification_expiry' WHERE email='$email'";
        if (mysqli_query($conn, $update_sql)) {
            // Send verification email
            if (sendVerificationEmail($email, $firstname, $verification_code)) {
                echo "<script>alert('New verification code sent to your email!');</script>";
                echo "<script>window.location.href = 'verify.php';</script>";
            } else {
                echo "<script>alert('Failed to send verification email. Please try again.');</script>";
                echo "<script>window.location.href = 'verify.php';</script>";
            }
        } else {
            echo "<script>alert('Error updating verification code. Please try again.');</script>";
            echo "<script>window.location.href = 'verify.php';</script>";
        }
    } else {
        echo "<script>alert('User not found. Please register again.');</script>";
        echo "<script>window.location.href = 'signup.php';</script>";
    }
}

mysqli_close($conn);
?>