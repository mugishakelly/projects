<?php
include "config/config.php";

if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: index.php");
    exit;
}

// Get user information
$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM customer WHERE customerid = $user_id";
$user_result = mysqli_query($conn, $user_query);
$user = mysqli_fetch_assoc($user_result);


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AGRIVISTA Customer Dashboard</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
  <style>
    <?php include "css/cudash.css"; ?>
  </style>
</head>
<body>
  <div class="dashboard">
    <!-- Sidebar -->
    <div class="sidebar">
      <div class="sidebar-header">
        <div class="logo">AGRIVISTA</div>
        <div class="sidebar-logo-text">Connecting You to Nature</div>
      </div>
      <div class="sidebar-menu">
        <a href="cudash.php" class="menu-item active">
          <i class="fas fa-home"></i> Dashboard
        </a>
        <a href="farms.php" class="menu-item">
          <i class="fas fa-leaf"></i> Farm Experiences
        </a>
        <a href="bookings.php" class="menu-item">
          <i class="fas fa-calendar-alt"></i> My Bookings
        </a>    
        <a href="favorite.php" class="menu-item">
          <i class="fas fa-heart"></i> Favorites
        </a>
        <a href="settings.php" class="menu-item">
          <i class="fas fa-cog"></i> Settings
        </a>
        <a href="help.php" class="menu-item">
          <i class="fas fa-question-circle"></i> Help & Support
        </a>
        <a href="logout.php" class="menu-item">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </div>
    </div>
    
    <!-- Main Content -->
  <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div class="page-title">Dashboard</div>
                <div class="user-info">
                    <div class="notification">
                        <i class="far fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </div>
                    <div class="user-avatar"><?php echo substr($user['first_name'], 0, 1); ?></div>
                    <div class="username"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></div>
                </div>
            </div>
            
            <?php if (isset($booking_error) && !empty($booking_error)): ?>
            <div class="alert alert-error">
                <?php echo $booking_error; ?>
            </div>
            <?php endif; ?>
      
      <!-- Dashboard Stats -->
      <div class="dashboard-cards">
        <div class="card">
          <div class="card-header">
            <div class="card-title">Upcoming Experience</div>
            <div class="card-icon">
              <i class="fas fa-calendar-check"></i>
            </div>
          </div>
          <div class="stat">2</div>
          <div class="stat-label">experiences booked this month</div>
        </div>
        
        <div class="card">1
          <div class="card-header">
            <div class="card-title">Farm Visits</div>
            <div class="card-icon">
              <i class="fas fa-tractor"></i>
            </div>
          </div>
          <div class="stat">7</div>
          <div class="stat-label">total farms visited</div>
        </div>
        
        <div class="card">
          <div class="card-header">
            <div class="card-title">Reward Points</div>
            <div class="card-icon">
              <i class="fas fa-star"></i>
            </div>
          </div>
          <div class="stat">350</div>
          <div class="stat-label">points available to redeem</div>
        </div>
      </div>
      
      <!-- Weather Widget -->
      <div class="weather-widget">
        <div class="weather-header">
          <div class="weather-location">Green Valley Farm Area</div>
          <div class="weather-date">Wednesday, April 09, 2025</div>
        </div>
        <div class="weather-content">
          <div class="weather-icon">
            <i class="fas fa-sun"></i>
          </div>
          <div class="weather-temp">72°F</div>
          <div class="weather-details">
            <div class="weather-condition">Mostly Sunny</div>
            <div class="weather-stats">
              <div class="weather-stat">
                <i class="fas fa-wind"></i> 8 mph
              </div>
              <div class="weather-stat">
                <i class="fas fa-tint"></i> 20%
              </div>
              <div class="weather-stat">
                <i class="fas fa-leaf"></i> High Pollen
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Upcoming Bookings -->
      <div class="section-title">
        <i class="fas fa-calendar-alt"></i> Upcoming Bookings
      </div>
      <div class="bookings-container">
        <div class="booking-card">
          <div class="booking-date">
            <div class="booking-day">15</div>
            <div class="booking-month">Apr</div>
          </div>
          <div class="booking-details">
            <div class="booking-title">Apple Picking Experience</div>
            <div class="booking-farm">Green Valley Orchards</div>
            <div class="booking-guests">2 Adults, 2 Children</div>
          </div>
          <div class="booking-status">
            <span class="status-badge status-confirmed">Confirmed</span>
          </div>
        </div>
        
        <div class="booking-card">
          <div class="booking-date">
            <div class="booking-day">22</div>
            <div class="booking-month">Apr</div>
          </div>
          <div class="booking-details">
            <div class="booking-title">Farm-to-Table Dinner</div>
            <div class="booking-farm">Sunset Farms</div>
            <div class="booking-guests">2 Adults</div>
          </div>
          <div class="booking-status">
            <span class="status-badge status-pending">Pending</span>
          </div>
        </div>
      </div>
</body>
</html>