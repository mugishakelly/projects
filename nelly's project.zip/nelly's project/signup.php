<?php
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';
require './PHPMailer/src/Exception.php';

// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include "config/config.php"; // Database connection file


// Function to generate random verification code
function generateVerificationCode($length = 6) {
    return substr(str_shuffle("0123456789"), 0, $length);
}

// Function to send verification email using PHPMailer
function sendVerificationEmail($email, $firstname, $verificationCode) {
    
    // // Require the PHPMailer autoloader
    // require 'vendor/autoload.php'; // Adjust path if needed
    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'uwitonzemugishak@gmail.com'; // Replace with your email
        $mail->Password   = ' qtht rwsx mzxg jhqf'; // Replace with your password
        $mail->SMTPSecure = 'tls'; // Use 'ssl' if your server requires it
        $mail->Port       = 587; // Use 465 for SSL
        
        // Recipients
        $mail->setFrom('AGRIVISTA@gmail.com', 'AGRIVISTA');
        $mail->addAddress($email);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "Verify Your AGRIVISTA Account";
        $mail->Body = "
        <html>
        <head>
            <title>Email Verification</title>
        </head>
        <body>
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;'>
                <h2 style='color: #4CAF50;'>Welcome to Agro Tourism, $firstname!</h2>
                <p>Thank you for registering with us. To complete your registration, please use the verification code below:</p>
                <div style='background-color: #f9f9f9; padding: 15px; text-align: center; font-size: 24px; letter-spacing: 5px; font-weight: bold; margin: 20px 0;'>
                    $verificationCode
                </div>
                <p>This code will expire in 24 hours.</p>
                <p>If you did not create an account, please ignore this email.</p>
                <p>Best regards,<br>The AGRIVISTA Team</p>
            </div>
        </body>
        </html>
        ";
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        // Log the error for debugging
        error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Sanitize and fetch input values
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];
    $farm_activities = isset($_POST['farm_activities']) ? implode(", ", $_POST['farm_activities']) : "";
    $referral_source = mysqli_real_escape_string($conn, $_POST['referral_source']);
    $country = mysqli_real_escape_string($conn, $_POST['country']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $user_experience = mysqli_real_escape_string($conn, $_POST['user_experience']);

    // Check if username or email already exists
    $check_user = "SELECT * FROM customer WHERE username='$username' OR email='$email'";
    $result = mysqli_query($conn, $check_user);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Username or email already exists!');</script>";
        exit;
    }
    
    // fill all the details
    if (empty($firstname) || empty($lastname) || empty($email) || empty($phone) || empty($username) || empty($password) || empty($confirmpassword)) {
        echo "<script>alert('Please fill in all required fields!');</script>";
        exit;
    }
    
    // Validate email format    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format!');</script>";
        exit;
    }

    // Password validation
    if ($password !== $confirmpassword) {
        echo "<script>alert('Passwords do not match!');</script>";
        exit;
    }

    // Generate verification code
    $verification_code = generateVerificationCode();
    $verification_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
    
    // Hash password for security
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    
    // Insert into database with verification status as 0 (unverified)
    $sql = "INSERT INTO customer (first_name, last_name, email, phone, username, password, farm_activities, 
            referral_source, country, state, user_experience, verification_code, verification_expiry, is_verified) 
            VALUES ('$firstname', '$lastname', '$email', '$phone', '$username', '$hashed_password', 
            '$farm_activities', '$referral_source', '$country', '$state', '$user_experience', 
            '$verification_code', '$verification_expiry', 0)";

    if (mysqli_query($conn, $sql)) {
        // Send verification email
        if (sendVerificationEmail($email, $firstname, $verification_code)) {
            // Store email in session for the verification page
            session_start();
            $_SESSION['temp_email'] = $email;
            
            // Redirect to verification page
            echo "<script>alert('Registration successful! Please check your email for verification code.');</script>";
            echo "<script>window.location.href = 'verification.php';</script>";
        } else {
            echo "<script>alert('Registration successful, but failed to send verification email. Please contact support.');</script>";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    // Close connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AGRIVISTA Signup</title>
  <style>
<?php include "css/sign.css"; ?>
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="header-decoration"></div>
      <div class="header-content">
        <h1>Join Our Agro Tourism Community</h1>
        <p class="subtitle">Create your account to discover unique farm experiences and connect with nature</p>
      </div>
    </header>
    
    <div class="form-container">
      <form  method="post" id="signup-form">
        <!-- Personal Information Section -->
        <div class="form-section">
          <div class="section-title">
            <i>👤</i> Personal Information
          </div>
          <div class="form-row">
            <div class="form-group half-width">
              <label class="form-label required">First Name</label>
              <input name = "firstname" type="text" class="form-control" placeholder="Enter your first name" required>
            </div>
            <div class="form-group half-width">
              <label class="form-label required">Last Name</label>
              <input name = "lastname" type="text" class="form-control" placeholder="Enter your last name" required>
            </div>
            <div class="form-group half-width">
              <label class="form-label required">Email Address</label>
              <input  name = "email" type="email" class="form-control" placeholder="your.email@example.com" required>
            </div>
            <div class="form-group half-width">
              <label class="form-label required">Phone Number</label>
              <input name = "phone" type="tel" class="form-control" placeholder="(555) 123-4567">
              <p class="input-hint">We'll send important updates about your bookings</p>
            </div>
          </div>
        </div>
        
        <!-- Account Information Section -->
        <div class="form-section">
          <div class="section-title">
            <i>🔐</i> Account Setup
          </div>
          <div class="form-row">
            <div class="form-group half-width">
              <label class="form-label required">Username</label>
              <input name = "username" type="text" class="form-control" placeholder="Choose a username" required>
            </div>
            <div class="form-group half-width">
              <label class="form-label required">Password</label>
              <input name = "password" type="password" class="form-control" placeholder="Create a strong password" required>
              <p class="input-hint">Use at least 8 characters with a mix of letters, numbers and symbols</p>
            </div>
            <div class="form-group half-width">
              <label class="form-label required">Confirm Password</label>
              <input name = "confirmpassword" type="password" class="form-control" placeholder="Confirm your password" required>
            </div>
          </div>
        </div>
        
        <!-- Preferences Section -->
        <div class="form-group full-width">
  <label class="form-label">What farm activities are you interested in?</label>
  <div class="checkboxes">
    <label><input type="checkbox" name="farm_activities[]" value="Organic Farming"> Organic Farming</label>
    <label><input type="checkbox" name="farm_activities[]" value="Livestock Experience"> Livestock Experience</label>
    <label><input type="checkbox" name="farm_activities[]" value="Fruit Picking"> Fruit Picking</label>
    <label><input type="checkbox" name="farm_activities[]" value="Farm-to-Table Dining"> Farm-to-Table Dining</label>
    <label><input type="checkbox" name="farm_activities[]" value="Vineyard Tours"> Vineyard Tours</label>
    <label><input type="checkbox" name="farm_activities[]" value="Farm Stays"> Farm Stays</label>
  </div>
</div>

        
        <!-- Location Information -->
<label class="form-label">How did you hear about us?</label>
<select style =  "margin-bottom: 5%" name="referral_source" class="form-control">
    <option value="social">Social Media</option>
    <option value="search">Search Engine</option>
    <option value="friend">Friend Referral</option>
    <option value="blog">Blog or Article</option>
    <option value="event">Agricultural Event</option>
    <option value="other">Other</option>
</select>
<div class="location">
  <label class="form-label">Country</label>
  <select name="country" class="form-control">
    <option value="us">United States</option>
    <option value="ca">Canada</option>
    <option value="uk">United Kingdom</option>
    <option value="au">Australia</option>
    <option value="other">Other</option>
  </select>

  <label class="form-label">State/Province</label>
  <input name="state" type="text" class="form-control" placeholder="Enter your state or province">
</div>



<label  class="form-label">Tell us more about what you hope to experience</label>
<textarea style = "margin-bottom: 5%" name="user_experience" class="form-control" placeholder="Share your interests..."></textarea>

        
        <!-- Terms and Conditions -->
        <div class="terms-container">
          <div class="checkbox-container" onclick="toggleCheckbox(this)" style="background: transparent; padding-left: 0;">
            <div class="custom-checkbox"></div>
            <p class="terms-text">
              I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>. I consent to receiving updates about farm experiences and promotions.
            </p>
          </div>
        </div>
        
        <!-- Submit Button -->
        <div class="btn-container">
          <button name = "submit" type="submit" class="btn">Create Account</button>
          <p class="login-link">Already have an account? <a href="index.php">Log In</a></p>
        </div>
      </form>
    </div>
  </div>

  <script>
    function toggleCheckbox(element) {
      const checkbox = element.querySelector('.custom-checkbox');
      checkbox.classList.toggle('checked');
    }
  </script>
</body>
</html>