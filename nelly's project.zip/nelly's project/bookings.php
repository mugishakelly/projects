<?php
// Include database connection
include "config/config.php";

// Start session to store booking information

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: index.php");
    exit;
}

// Get user information
$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM customer WHERE customerid = $user_id";
$user_result = mysqli_query($conn, $user_query);
$user = mysqli_fetch_assoc($user_result);

// Get available farm experiences
$experiences_query = "SELECT * FROM farm_experiences WHERE availability = 1";
$experiences_result = mysqli_query($conn, $experiences_query);

// Process booking submission
$booking_success = false;
$booking_error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_booking'])) {
    // Sanitize and validate input
    $experience_id = mysqli_real_escape_string($conn, $_POST['experience_id']);
    $booking_date = mysqli_real_escape_string($conn, $_POST['booking_date']);
    $booking_time = mysqli_real_escape_string($conn, $_POST['booking_time']);
    $adults = (int)$_POST['adults'];
    $children = (int)$_POST['children'];
    $special_requests = mysqli_real_escape_string($conn, $_POST['special_requests']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    
    // Validate inputs
    if (empty($experience_id) || empty($booking_date) || empty($booking_time) || $adults <= 0) {
        $booking_error = "Please fill in all required fields.";
    } else {
        // Calculate total participants
        $total_participants = $adults + $children;
        
        // Get experience details for price calculation
        $exp_query = "SELECT * FROM farm_experiences WHERE farmid = $experience_id";
        $exp_result = mysqli_query($conn, $exp_query);
        $experience = mysqli_fetch_assoc($exp_result);
        
        // Calculate total price
        $adult_price = $experience['price_adult'];
        $child_price = $experience['price_child'];
        $total_price = ($adults * $adult_price) + ($children * $child_price);
        
        // Generate booking reference
        $booking_reference = 'AGRI-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
        
        // Insert booking into database
        $booking_datetime = $booking_date . ' ' . $booking_time . ':00';
        
        $insert_query = "INSERT INTO bookings (customerid, farmid, booking_reference, booking_datetime, 
                        adults, children, total_participants, special_requests, payment_method, total_price, 
                        status, created_at) 
                        VALUES ($user_id, $experience_id, '$booking_reference', '$booking_datetime', 
                        $adults, $children, $total_participants, '$special_requests', '$payment_method', 
                        $total_price, 'pending', NOW())";
        
        if (mysqli_query($conn, $insert_query)) {
            $booking_id = mysqli_insert_id($conn);
            
            // Store booking ID in session for confirmation page
            $_SESSION['booking_id'] = $booking_id;
            
            // Set success flag
            $booking_success = true;
            
            // Redirect to confirmation page
            header("Location: bookings.php ");
            exit;
        } else {
            $booking_error = "Error creating booking: " . mysqli_error($conn);
        }
    }
}

// Function to get available time slots
function getTimeSlots() {
    $time_slots = array();
    $start = strtotime("08:00");
    $end = strtotime("17:00");
    $interval = 60 * 60; // 1 hour interval
    
    for ($time = $start; $time <= $end; $time += $interval) {
        $time_slots[] = date("H:i", $time);
    }
    
    return $time_slots;
}

$time_slots = getTimeSlots();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Farm Experience - AGRIVISTA</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        <?php include "css/cudash.css"; ?>
        <?php include "css/booking.css"; ?>
    </style>
</head>
<body>
<div class="dashboard">
    <!-- Sidebar -->
    <div class="sidebar">
      <div class="sidebar-header">
        <div class="logo">AGRIVISTA</div>
        <div class="sidebar-logo-text">Connecting You to Nature</div>
      </div>
      <div class="sidebar-menu">
        <a href="cudash.php" class="menu-item active">
          <i class="fas fa-home"></i> Dashboard
        </a>
        <a href="farms.php" class="menu-item">
          <i class="fas fa-leaf"></i> Farm Experiences
        </a>
        <a href="bookings.php" class="menu-item">
          <i class="fas fa-calendar-alt"></i> My Bookings
        </a> 
        <a href="favorite.php" class="menu-item">
          <i class="fas fa-heart"></i> Favorites
        </a>
        <a href="settings.php" class="menu-item">
          <i class="fas fa-cog"></i> Settings
        </a>
        <a href="help.php" class="menu-item">
          <i class="fas fa-question-circle"></i> Help & Support
        </a>
        <a href="logout.php" class="menu-item">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </div>
    </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div class="page-title">Book Farm Experience</div>
                <div class="user-info">
                    <div class="notification">
                        <i class="far fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </div>
                    <div class="user-avatar"><?php echo substr($user['first_name'], 0, 1); ?></div>
                    <div class="username"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></div>
                </div>
            </div>
            
            <?php if (isset($booking_error) && !empty($booking_error)): ?>
            <div class="alert alert-error">
                <?php echo $booking_error; ?>
            </div>
            <?php endif; ?>
            
            <!-- Booking Form -->
            <div class="booking-container">
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" id="booking-form">
                    <div class="form-title">Select Farm Experience</div>
                    
                    <?php 
                    // Check if experiences are available
                    if (mysqli_num_rows($experiences_result) > 0):
                        while ($experience = mysqli_fetch_assoc($experiences_result)):
                    ?>
                    <div class="experience-card">
                        <img src="<?php echo $experience['image_url']; ?>" alt="<?php echo $experience['title']; ?>" class="experience-image">
                        <div class="experience-details">
                            <h3 class="experience-title"><?php echo $experience['title']; ?></h3>
                            <div class="experience-location">
                                <i class="fas fa-map-marker-alt"></i> 
                                <?php echo $experience['location']; ?>
                            </div>
                            <p class="experience-description">
                                <?php echo $experience['description']; ?>
                            </p>
                            <div class="experience-meta">
                                <div class="meta-item">
                                    <i class="fas fa-clock"></i> 
                                    <span><?php echo $experience['duration']; ?> hours</span>
                                </div>
                                <div class="meta-item">
                                    <i class="fas fa-users"></i> 
                                    <span>Max <?php echo $experience['max_participants']; ?> people</span>
                                </div>
                            </div>
                            <div class="experience-price">
                                $<?php echo $experience['price_adult']; ?> per adult
                                <span class="price-details">
                                    | $<?php echo $experience['price_child']; ?> per child (under 12)
                                </span>
                            </div>
                            <div class="input-hint">
                                <input type="radio" name="experience_id" value="<?php echo $experience['farmid']; ?>" required>
                                Select this experience
                            </div>
                        </div>
                    </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <p>No farm experiences available at the moment. Please check back later.</p>
                    <?php endif; ?>
                    
                    <div class="form-title">Booking Details</div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label required">Select Date</label>
                            <?php
                            // Calculate min date (tomorrow) and max date (6 months from now)
                            $min_date = date('Y-m-d', strtotime('+1 day'));
                            $max_date = date('Y-m-d', strtotime('+6 months'));
                            ?>
                            <input type="date" name="booking_date" class="form-control" required
                                   min="<?php echo $min_date; ?>" max="<?php echo $max_date; ?>">
                            <p class="input-hint">Select a date between tomorrow and 6 months from now</p>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label required">Select Time</label>
                            <select name="booking_time" class="form-control" required>
                                <option value="">Select a time</option>
                                <?php foreach ($time_slots as $time): ?>
                                <option value="<?php echo $time; ?>"><?php echo $time; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="input-hint">Farm experiences available between 8:00 AM and 5:00 PM</p>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label required">Number of Adults</label>
                            <div class="number-input">
                                <div class="number-btn" onclick="decrementValue('adults')">-</div>
                                <input type="number" name="adults" id="adults" value="0" min="0" max="10" required>
                                <div class="number-btn" onclick="incrementValue('adults')">+</div>
                            </div>
                            <p class="input-hint">At least 1 adult required</p>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Number of Children (Under 12)</label>
                            <div class="number-input">
                                <div class="number-btn" onclick="decrementValue('children')">-</div>
                                <input type="number" name="children" id="children" value="0" min="0" max="10">
                                <div class="number-btn" onclick="incrementValue('children')">+</div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Special Requests or Requirements</label>
                            <textarea name="special_requests" class="form-control" placeholder="Any dietary restrictions, accessibility needs, or special requests..."></textarea>
                            <p class="input-hint">We'll do our best to accommodate your needs</p>
                        </div>
                    </div>
                    
                    <div class="form-title">Payment Method</div>
                    
                    <div class="payment-methods">
                        <div class="payment-method">
                            <input type="radio" name="payment_method" id="credit_card" value="credit_card" checked>
                            <label for="credit_card">
                                <i class="fas fa-credit-card"></i>
                                <span>Credit Card</span>
                            </label>
                        </div>
                        
                        <div class="payment-method">
                            <input type="radio" name="payment_method" id="paypal" value="paypal">
                            <label for="paypal">
                                <i class="fab fa-paypal"></i>
                                <span>PayPal</span>
                            </label>
                        </div>
                        
                        <div class="payment-method">
                            <input type="radio" name="payment_method" id="bank_transfer" value="bank_transfer">
                            <label for="bank_transfer">
                                <i class="fas fa-university"></i>
                                <span>Bank Transfer</span>
                            </label>
                        </div>
                        
                        <div class="payment-method">
                            <input type="radio" name="payment_method" id="mobile_payment" value="mobile_payment">
                            <label for="mobile_payment">
                                <i class="fas fa-mobile-alt"></i>
                                <span>Mobile Payment</span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="booking-summary" id="booking-summary">
                        <h3 class="summary-title">Booking Summary</h3>
                        <div class="summary-row">
                            <span class="summary-label">Farm Experience:</span>
                            <span class="summary-value" id="summary-experience">Please select an experience</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">Date:</span>
                            <span class="summary-value" id="summary-date">-</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">Time:</span>
                            <span class="summary-value" id="summary-time">-</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">Adults:</span>
                            <span class="summary-value" id="summary-adults">1 ($0)</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">Children:</span>
                            <span class="summary-value" id="summary-children">0 ($0)</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">Payment Method:</span>
                            <span class="summary-value" id="summary-payment">Credit Card</span>
                        </div>
                        <div class="summary-row">
                            <span class="summary-label">Total:</span>
                            <span class="summary-total" id="summary-total">$0.00</span>
                        </div>
                    </div>
                    
                    <div class="btn-container">
                        <a href="farm_experiences.php" class="btn btn-secondary">Back to Experiences</a>
                        <button type="submit" name="submit_booking" class="btn btn-primary">Confirm Booking</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
    function incrementValue(id) {
        const input = document.getElementById(id);
        const max = parseInt(input.getAttribute('max'));
        let value = parseInt(input.value) || 0;

        if (value < max) {
            input.value = value + 1;
            updateSummary();
        }
    }

    function decrementValue(id) {
        const input = document.getElementById(id);
        const min = parseInt(input.getAttribute('min'));
        let value = parseInt(input.value) || 0;

        if (value > min) {
            input.value = value - 1;
            updateSummary();
        }
    }

    const experiencePrices = {};
    <?php 
    mysqli_data_seek($experiences_result, 0);
    while ($exp = mysqli_fetch_assoc($experiences_result)): ?>
        experiencePrices[<?php echo $exp['farmid']; ?>] = {
            title: "<?php echo addslashes($exp['title']); ?>",
            adultPrice: <?php echo $exp['price_adult']; ?>,
            childPrice: <?php echo $exp['price_child']; ?>
        };
    <?php endwhile; ?>

    function updateSummary() {
        const selectedExperience = document.querySelector('input[name="experience_id"]:checked');
        const dateInput = document.querySelector('input[name="booking_date"]');
        const timeSelect = document.querySelector('select[name="booking_time"]');
        const adultsInput = document.getElementById('adults');
        const childrenInput = document.getElementById('children');
        const paymentMethod = document.querySelector('input[name="payment_method"]:checked');

        const summaryExperience = document.getElementById('summary-experience');
        const summaryDate = document.getElementById('summary-date');
        const summaryTime = document.getElementById('summary-time');
        const summaryAdults = document.getElementById('summary-adults');
        const summaryChildren = document.getElementById('summary-children');
        const summaryPayment = document.getElementById('summary-payment');
        const summaryTotal = document.getElementById('summary-total');

        if (selectedExperience) {
            const expId = selectedExperience.value;
            if (experiencePrices[expId]) {
                summaryExperience.textContent = experiencePrices[expId].title;

                const adults = parseInt(adultsInput.value) || 0;
                const children = parseInt(childrenInput.value) || 0;
                const adultCost = adults * experiencePrices[expId].adultPrice;
                const childCost = children * experiencePrices[expId].childPrice;
                const total = adultCost + childCost;

                summaryAdults.textContent = `${adults} ($${adultCost.toFixed(2)})`;
                summaryChildren.textContent = `${children} ($${childCost.toFixed(2)})`;
                summaryTotal.textContent = `$${total.toFixed(2)}`;
            }
        } else {
            summaryExperience.textContent = "Please select an experience";
            summaryTotal.textContent = "$0.00";
        }

        if (dateInput.value) {
            const selectedDate = new Date(dateInput.value);
            summaryDate.textContent = selectedDate.toLocaleDateString('en-US', {
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
            });
        } else {
            summaryDate.textContent = "-";
        }

        summaryTime.textContent = timeSelect.value || "-";

        if (paymentMethod) {
            let paymentText = paymentMethod.value.replace(/_/g, ' ');
            paymentText = paymentText.replace(/\b\w/g, char => char.toUpperCase());
            summaryPayment.textContent = paymentText;
        }
    }

    function validateForm() {
        const selectedExperience = document.querySelector('input[name="experience_id"]:checked');
        const dateInput = document.querySelector('input[name="booking_date"]');
        const timeSelect = document.querySelector('select[name="booking_time"]');

        if (!selectedExperience) {
            alert('Please select a farm experience to continue.');
            return false;
        }
        if (!dateInput.value) {
            alert('Please select a booking date.');
            return false;
        }
        if (!timeSelect.value) {
            alert('Please select a booking time.');
            return false;
        }

        return true;
    }

    document.addEventListener('DOMContentLoaded', function () {
        const formElements = document.querySelectorAll(
            'input[name="experience_id"], input[name="booking_date"], select[name="booking_time"], #adults, #children, input[name="payment_method"]'
        );

        formElements.forEach(el => {
            el.addEventListener('change', updateSummary);
            el.addEventListener('input', updateSummary); // Also track real-time input changes
        });

        document.getElementById('booking-form').addEventListener('submit', function (e) {
            if (!validateForm()) {
                e.preventDefault();
            }
        });

        updateSummary(); // Initialize on page load
    });
</script>
</body>
</html>