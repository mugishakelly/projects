<?php
// Start session to maintain login state


// Check if user is logged in and is admin
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
//     header("Location: index.php");
//     exit();
// }

// Include database connection
include "../config/config.php";

// Get some statistics for the dashboard
$totalUsers = 0;
$totalBookings = 0;
$totalRevenue = 0;
$recentBookings = [];

// Count total users
$query = "SELECT COUNT(*) as total FROM customer ";
$result = mysqli_query($conn, $query);
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $totalUsers = $row['total'];
}

// Count total bookings
$query = "SELECT COUNT(*) as total FROM bookings";
$result = mysqli_query($conn, $query);
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $totalBookings = $row['total'];
}

// Calculate total revenue
$query = "SELECT SUM(amount) as total FROM payments WHERE status = 'completed'";
$result = mysqli_query($conn, $query);
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $totalRevenue = $row['total'] ? $row['total'] : 0;
}

// Get recent bookings
$query = "SELECT b.id, c.first_name, c.last_name, b.booking_date, b.status, b.amount 
          FROM bookings b 
          JOIN customer c ON b.customer_id = c.id 
          ORDER BY b.booking_date DESC LIMIT 5";
$result = mysqli_query($conn, $query);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $recentBookings[] = $row;
    }
}

// Get farm activities distribution
$farmActivities = [
    'Organic Farming' => 0,
    'Livestock Experience' => 0,
    'Fruit Picking' => 0,
    'Farm-to-Table Dining' => 0,
    'Vineyard Tours' => 0,
    'Farm Stays' => 0
];

$query = "SELECT farm_activities FROM customer WHERE farm_activities IS NOT NULL";
$result = mysqli_query($conn, $query);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $activities = explode(", ", $row['farm_activities']);
        foreach ($activities as $activity) {
            if (isset($farmActivities[$activity])) {
                $farmActivities[$activity]++;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Agro Tourism</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <style>
        <?php include "assets/css/dash.css"; ?>
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-leaf"></i>
                    <span>AGRIVISTA</span>
                </div>
            </div>
            
            <nav class="sidebar-menu">
                <a href="dashboard.php" class="menu-item active">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="user.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
                <a href="booking.php" class="menu-item">
                    <i class="fas fa-calendar-check"></i>
                    <span>Bookings</span>
                </a>
                <a href="experiences.php" class="menu-item">
                    <i class="fas fa-tractor"></i>
                    <span>Farm Experiences</span>
                </a>
                <a href="payments.php" class="menu-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Payments</span>
                </a>
                <a href="php" class="menu-item">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports</span>
                </a>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cogs"></i>
                    <span>Settings</span>
                </a>
            </nav>
            
            <div class="user-info">
                <div class="user-avatar">
                    A
                </div>
                <div class="user-details">
                    <div class="user-name">Admin User</div>
                    <div class="user-role">Administrator</div>
                </div>
            </div>
        </aside>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navigation -->
            <div style = "margin-bottom: 3%" class="top-nav">
                <div class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </div>
                
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search...">
                </div>
                
                <div class="nav-actions">
                    <div class="nav-action-item">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </div>
                    <div class="nav-action-item">
                        <i class="fas fa-envelope"></i>
                        <span class="notification-badge">5</span>
                    </div>
                    <a href="logout.php" class="nav-action-item">
                        <div class="nav-action-item">
                            <i class="fas fa-sign-out-alt"></i>
                        </div>
                    </a>
                </div>
            </div>
            
            <!-- Page Header -->
            <div class="page-header">
                <h1 class="page-title">Dashboard</h1>
                <div class="breadcrumb">
                    Home / <span>Dashboard</span>
                </div>
            </div>
            
            <!-- Stats Cards -->
            <div class="cards">
                <div class="card">
                    <div class="card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="card-title">Total Users</div>
                    <div class="card-value"><?php echo number_format($totalUsers); ?></div>
                    <div class="card-change positive">
                        <i class="fas fa-arrow-up"></i> 12% from last month
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="card-title">Total Bookings</div>
                    <div class="card-value"><?php echo number_format($totalBookings); ?></div>
                    <div class="card-change positive">
                        <i class="fas fa-arrow-up"></i> 8% from last month
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="card-title">Total Revenue</div>
                    <div class="card-value">$<?php echo number_format($totalRevenue, 2); ?></div>
                    <div class="card-change positive">
                        <i class="fas fa-arrow-up"></i> 15% from last month
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="card-title">Average Rating</div>
                    <div class="card-value">4.8</div>
                    <div class="card-change positive">
                        <i class="fas fa-arrow-up"></i> 0.2 from last month
                    </div>
                </div>
            </div>
            
            <!-- Charts Section -->
            <div class="charts-section">
                <div class="chart-container">
                    <div class="section-header">
                        <h2 class="section-title">Bookings Overview</h2>
                        <a href="reports.php" class="see-all">
                            Detailed Reports <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                    <canvas id="bookingsChart" height="250"></canvas>
                </div>
                
                <div class="chart-container">
                    <div class="section-header">
                        <h2 class="section-title">Popular Farm Activities</h2>
                        <a href="reports.php?type=activities" class="see-all">
                            View All <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                    
                    <?php
                    $colors = [
                        'rgba(76, 175, 80, 0.8)',
                        'rgba(33, 150, 243, 0.8)',
                        'rgba(255, 193, 7, 0.8)',
                        'rgba(156, 39, 176, 0.8)',
                        'rgba(233, 30, 99, 0.8)',
                        'rgba(0, 188, 212, 0.8)'
                    ];
                    
                    $i = 0;
                    foreach ($farmActivities as $activity => $count) {
                        $color = $colors[$i % count($colors)];
                        echo '<div class="activity-type">
                                <div class="activity-color" style="background-color: '.$color.'"></div>
                                <div class="activity-name">'.$activity.'</div>
                                <div class="activity-value">'.$count.'</div>
                              </div>';
                        $i++;
                    }
                    ?>
                </div>

        
</body>
</html>