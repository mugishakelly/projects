<?php 
include "../config/config.php";

// Function to generate random verification code
function generateVerificationCode($length = 6) {
    return substr(str_shuffle("0123456789"), 0, $length);
}

// Function to send verification email
function sendVerificationEmail($email, $firstname, $verificationCode) {
    $subject = "Verify AGRIVISTA Account";

    $message = "
    <html>
    <head>
        <title>Email Verification</title>
    </head>
    <body>
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;'>
            <h2 style='color: #4CAF50;'>Welcome to Agro Tourism, $firstname!</h2>
            <p>Thank you for registering. Use the verification code below:</p>
            <div style='background-color: #f9f9f9; padding: 15px; text-align: center; font-size: 24px; letter-spacing: 5px; font-weight: bold; margin: 20px 0;'>
                $verificationCode
            </div>
            <p>This code expires in 24 hours.</p>
        </div>
    </body>
    </html>
    ";

    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8\r\n";
    $headers .= "From: noreply@agrotourism.com\r\n";

    return mail($email, $subject, $message, $headers);
}

// Redirect to signup if no session email
if (!isset($_SESSION['temp_email'])) {
    header("Location: signup.php");
    exit();
}

$email = $_SESSION['temp_email'];

// --- HANDLE VERIFICATION ---
if (isset($_POST['verify'])) {
    $verification_code = mysqli_real_escape_string($conn, $_POST['verification_code']);

    $sql = "SELECT * FROM admin WHERE adminemail='$email' AND verification_code='$verification_code' AND verification_expiry > NOW()";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $update_sql = "UPDATE admin SET is_verified=1 WHERE adminemail='$email'";
        if (mysqli_query($conn, $update_sql)) {
            unset($_SESSION['temp_email']);
            echo "<script>alert('Email verified successfully! You can now log in.');</script>";
            echo "<script>window.location.href = 'index.php';</script>";
            exit();
        } else {
            echo "<script>alert('Verification update failed.');</script>";
        }
    } else {
        echo "<script>alert('Invalid or expired verification code.');</script>";
    }
}

// --- HANDLE RESEND ---
if (isset($_POST['resend_code'])) {
    $sql = "SELECT adminname FROM admin WHERE adminemail='$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $firstname = $row['adminname'];
        $verification_code = generateVerificationCode();
        $verification_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));

        $update_sql = "UPDATE admin SET verification_code='$verification_code', verification_expiry='$verification_expiry' WHERE adminemail='$email'";
        if (mysqli_query($conn, $update_sql)) {
            if (sendVerificationEmail($email, $firstname, $verification_code)) {
                echo "<script>alert('New code sent to your email!');</script>";
            } else {
                echo "<script>alert('Failed to send email.');</script>";
            }
        } else {
            echo "<script>alert('Error updating code.');</script>";
        }
    } else {
        echo "<script>alert('User not found.');</script>";
        header("Location: signup.php");
        exit();
    }
}

mysqli_close($conn);
?>