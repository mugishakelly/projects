<?php

require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';
require './PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include "../config/config.php"; // Database connection file

$role = isset($_POST['role']) ? $_POST['role'] : '';

// Function to generate random verification code
function generateVerificationCode($length = 6) {
    return substr(str_shuffle("0123456789"), 0, $length);
}

// Function to send verification email
function sendVerificationEmail($email, $firstname, $verificationCode) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'uwitonzemugishak@gmail.com'; // Replace with your email
        $mail->Password   = 'qthtrwsxmzxgjhqf'; // 🔒 Move this to a config file or .env in production
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('AGRIVISTA@gmail.com', 'AGRIVISTA');
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = "Verify Your AGRIVISTA Account";
        $mail->Body = "
        <html>
        <body>
            <div style='font-family: Arial; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px; max-width: 600px; margin: auto;'>
                <h2 style='color: #4CAF50;'>Welcome to Agro Tourism, $firstname!</h2>
                <p>Thank you for registering. Use the verification code below:</p>
                <div style='background: #f9f9f9; padding: 15px; text-align: center; font-size: 24px; letter-spacing: 5px; font-weight: bold; margin: 20px 0;'>$verificationCode</div>
                <p>This code will expire in 24 hours.</p>
                <p>If you did not create an account, ignore this email.</p>
                <p>– The AGRIVISTA Team</p>
            </div>
        </body>
        </html>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    if (empty($firstname) || empty($email) || empty($username) || empty($password) || empty($confirmpassword)) {
        echo "<script>alert('Please fill in all required fields!');</script>";
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format!');</script>";
        exit;
    }

    if ($password !== $confirmpassword) {
        echo "<script>alert('Passwords do not match!');</script>";
        exit;
    }

    $check_user = "SELECT * FROM admin WHERE username='$username' OR adminemail='$email'";
    $result = mysqli_query($conn, $check_user);
    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Username or email already exists!');</script>";
        exit;
    }

    $verification_code = generateVerificationCode();
    $verification_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    $sql = "INSERT INTO admin (adminname, adminemail, username, adminpass, role, verification_code, verification_expiry, is_verified)
            VALUES ('$firstname', '$email', '$username', '$hashed_password', '$role', '$verification_code', '$verification_expiry', 0)";

    if (mysqli_query($conn, $sql)) {
        if (sendVerificationEmail($email, $firstname, $verification_code)) {
            session_start();  
            $_SESSION['temp_email'] = $email;
            echo "<script>alert('Registration successful! Please check your email for the verification code.');</script>";
            echo "<script>window.location.href = 'verification.php';</script>";
        } else {
            echo "<script>alert('Registration succeeded, but email sending failed. Contact support.');</script>";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AGRIVISTA - Signup</title>
  <link rel="stylesheet" href="assets/css/sign.css">
</head>
<body>
  <div class="container">
    <header>
      <div class="header-decoration"></div>
      <div class="header-content">
        <h1>Join Our Agro Tourism Community</h1>
        <p class="subtitle">Create your account to discover unique farm experiences and connect with nature</p>
      </div>
    </header>
    
    <div class="form-container">
      <form method="post" id="signup-form">
        <div class="form-section">
          <div class="section-title">👤 Personal Information</div>
          <div class="form-row">
            <div class="form-group half-width">
              <label class="form-label required">Enter Name</label>
              <input name="firstname" type="text" class="form-control" placeholder="Enter your full name" required>
            </div>
            <div class="form-group half-width">
              <label class="form-label required">Email Address</label>
              <input name="email" type="email" class="form-control" placeholder="your.email@example.com" required>
            </div>
          </div>
        </div>

        <div class="form-section">
          <div class="section-title">🔐 Account Setup</div>
          <div class="form-row">
            <div class="form-group half-width">
              <label class="form-label required">Username</label>
              <input name="username" type="text" class="form-control" placeholder="Choose a username" required>
            </div>
            <div class="form-group half-width">
              <label class="form-label required">Password</label>
              <input name="password" type="password" class="form-control" placeholder="Create a strong password" required>
              <p class="input-hint">Use at least 8 characters with a mix of letters, numbers and symbols</p>
            </div>
            <div class="form-group half-width">
              <label class="form-label required">Confirm Password</label>
              <input name="confirmpassword" type="password" class="form-control" placeholder="Confirm your password" required>
            </div>
          </div>
          <div class="form-group half-width">
            <label class="form-label">Select your role</label>
            <select name="role" class="form-control role-select" required>
              <option value="" disabled selected>Select your role</option>
              <option value="admin" <?php if ($role == "admin") echo "selected"; ?>>Administrator</option>
              <option value="manager" <?php if ($role == "manager") echo "selected"; ?>>Manager</option>
              <option value="finance" <?php if ($role == "finance") echo "selected"; ?>>Finance</option>
            </select>
          </div>
        </div>

        <div class="terms-container">
          <div class="checkbox-container" onclick="toggleCheckbox(this)">
            <div class="custom-checkbox"></div>
            <p class="terms-text">
              I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>. I consent to receiving updates about farm experiences and promotions.
            </p>
          </div>
        </div>

        <div class="btn-container">
          <button name="submit" type="submit" class="btn">Create Account</button>
          <p class="login-link">Already have an account? <a href="login.php">Log In</a></p>
        </div>
      </form>
    </div>
  </div>

  <script>
    function toggleCheckbox(element) {
      const checkbox = element.querySelector('.custom-checkbox');
      checkbox.classList.toggle('checked');
    }
  </script>
</body>
</html>
