<?php
include '../config/config.php'; // Include your database connection file

// Check if email is stored in session
if (!isset($_SESSION['temp_email'])) {
    // Redirect to registration page if no email is found
    header("Location: signup.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your Email</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-image: url('images/farm-background-light.jpg');
            background-size: cover;
            background-position: center;
        }
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 500px;
            padding: 30px;
            text-align: center;
        }
        .icon {
            font-size: 48px;
            margin-bottom: 20px;
            color: #4CAF50;
        }
        h1 {
            color: #333;
            margin-bottom: 15px;
        }
        p {
            color: #666;
            margin-bottom: 25px;
            line-height: 1.6;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            letter-spacing: 5px;
            text-align: center;
        }
        .btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            width: 100%;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .resend {
            margin-top: 20px;
            color: #4CAF50;
            text-decoration: none;
            cursor: pointer;
        }
        .resend:hover {
            text-decoration: underline;
        }
        .email-highlight {
            font-weight: bold;
            color: #4CAF50;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">✉️</div>
        <h1>Verify Your Email</h1>
        <p>We've sent a verification code to <span class="email-highlight"><?php echo htmlspecialchars($_SESSION['temp_email']); ?></span>. Please enter the code below to complete your registration.</p>
        
        <form action="verify_process.php" method="post">
            <input type="text" class="form-control" name="verification_code" placeholder="Enter code" maxlength="6" required>
            <button type="submit" name="verify" class="btn">Verify Email</button>
        </form>
        
        <form action="verify_process.php" method="post">
            <button type="submit" name="resend_code" class="resend">Didn't receive a code? Resend</button>
        </form>
    </div>
</body>
</html>