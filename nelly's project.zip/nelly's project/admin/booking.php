<?php

include "../config/config.php";

// delete user 

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM customer WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "<script>alert('User deleted successfully!');</script>";
    } else {
        echo "<script>alert('Error deleting user!');</script>";
    }
}

if (isset($_GET['confirm'])) {
    $bookingid = $_GET['confirm'];
    $sql = "UPDATE bookings SET status = 'Confirmed' WHERE bookingid = $bookingid";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<script>alert('Booking confirmed successfully!');</script>";
        echo "<script>window.location.href='booking.php';</script>";
    } else {
        echo "<script>alert('Error confirming booking.');</script>";
    }
}


if (isset($_GET['decline'])) {
    $bookingid = $_GET['decline'];
    $sql = "UPDATE bookings SET status = 'Declined' WHERE bookingid = $bookingid";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<script>alert('Booking Declined try again sometime!');</script>";
        echo "<script>window.location.href='booking.php';</script>";
    } else {
        echo "<script>alert('Error confirming booking.');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Agro Tourism</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <style>
        <?php include "assets/css/dash.css"; ?>
        <?php include "assets/css/user.css"; ?>
        <?php include "assets/css/booking.css"; ?>
    </style>
</head>
<body>
<div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-leaf"></i>
                    <span>AGRIVISTA</span>
                </div>
            </div>
            
            <nav class="sidebar-menu">
                <a href="dashboard.php" class="menu-item active">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="user.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
                <a href="booking.php" class="menu-item">
                    <i class="fas fa-calendar-check"></i>
                    <span>Bookings</span>
                </a>
                <a href="experiences.php" class="menu-item">
                    <i class="fas fa-tractor"></i>
                    <span>Farm Experiences</span>
                </a>
                <a href="payments.php" class="menu-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Payments</span>
                </a>
                <a href="php" class="menu-item">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports</span>
                </a>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cogs"></i>
                    <span>Settings</span>
                </a>
            </nav>
            
            <div class="user-info">
                <div class="user-avatar">
                    A
                </div>
                <div class="user-details">
                    <div class="user-name">Admin User</div>
                    <div class="user-role">Administrator</div>
                </div>
            </div>
        </aside>


        <div class="main-content">
            <!-- Top Navigation -->
            <div style = "margin-bottom: 3%" class="top-nav">
                <div class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </div>
                
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search...">
                </div>
                
                <div class="nav-actions">
                    <div class="nav-action-item">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </div>
                    <div class="nav-action-item">
                        <i class="fas fa-envelope"></i>
                        <span class="notification-badge">5</span>
                    </div>
                    <a href="logout.php" class="nav-action-item">
                        <div class="nav-action-item">
                            <i class="fas fa-sign-out-alt"></i>
                        </div>
                    </a>
                </div>
            </div>
            
            <!-- Page Header -->
            <div class="page-header">
                <h1 class="page-title">Dashboard</h1>
                <div class="breadcrumb">
                    Home / <span>Users</span>
                </div>
            </div>


    <!-- bookings table  -->
          

        <table>

            <tr>
                <th>Booking ID</th>
                <th>Customer name</th>
                <th>Booking Date</th>
                <th>payment method</th>
                <th>Booking status</th>
                <th>Actions</th>
                <th>Booking confimation</th>
            
            </tr>   

            <?php
$sql = "SELECT bookings.bookingid, customer.first_name, customer.last_name, bookings.booking_datetime, bookings.payment_method, bookings.status FROM bookings INNER JOIN customer ON bookings.customerid = customer.customerid";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn)); // Show the SQL error for debugging
}

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['bookingid'] . "</td>";
        echo "<td>" . $row['first_name'] . " " . $row['last_name'] . "</td>";
        echo "<td>" . $row['booking_datetime'] . "</td>";
        echo "<td>" . $row['payment_method'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "<td><a href='?delete=" . $row['bookingid'] . "' class='delete-button'>Delete</a></td>";
        echo "<td>";
    if ($row['status'] != 'Confirmed') {
    echo "<a href='?confirm=" . $row['bookingid'] . "' class='confirm-button'>Confirm</a>";
    echo "<a href='?decline=" . $row['bookingid'] . "' class='decline-button'>decline</a>";
    } else {
    echo "Confirmed";
    }
    echo "</td>";
        echo "</tr>";
    }
    } else {
    echo "<tr><td colspan='6'>No bookings found</td></tr>";
    }
?>

        </table>



        
                
</body>
</html>