<?php
// Include database connection
include "../config/config.php";


// // Check if user is logged in and is an admin
// if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
//     // Redirect to login page if not logged in as admin
//     header("Location: login.php");
//     exit;
// }


if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM farm_experiences WHERE farmid = $id";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "<script>alert('Experience deleted successfully!');</script>";
    } else {
        echo "<script>alert('Error deleting experience!');</script>";
    }
}

// Get admin information
$admin_id = (int)$_SESSION['user_id'];
$admin_query = "SELECT * FROM customer ";
$admin_result = mysqli_query($conn, $admin_query);
if (!$admin_result) {
    die("Error fetching admin data: " . mysqli_error($conn));
}
$admin = mysqli_fetch_assoc($admin_result);

if (!$admin) {
    echo "<script>alert('Access denied. Admin account not found.'); window.location.href='login.php';</script>";
    exit;
}
// Process form submission
$success_message = "";
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_experience'])) {
    // Sanitize and validate input
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $duration = floatval($_POST['duration']);
    $max_participants = intval($_POST['max_participants']);
    $price_adult = floatval($_POST['price_adult']);
    $price_child = floatval($_POST['price_child']);
    $availability = isset($_POST['availability']) ? 1 : 0;
    
    // Image upload handling
    $image_url = "";
    $upload_dir = "images/experiences/";
    
    // Create directory if it doesn't exist
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        if (in_array($_FILES['image']['type'], $allowed_types)) {
            // Generate unique filename
            $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $file_name = 'experience_' . time() . '_' . rand(1000, 9999) . '.' . $file_extension;
            $target_file = $upload_dir . $file_name;
            
            // Move uploaded file
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_url = $target_file;
            } else {
                $error_message = "Error uploading file.";
            }
        } else {
            $error_message = "Invalid file type. Only JPG and PNG files are allowed.";
        }
    } else {
        $error_message = "Please upload an image for the farm experience.";
    }
    
    // If no errors, insert the experience into database
    if (empty($error_message)) {
        $insert_query = "INSERT INTO farm_experiences (title, description, location, image_url, duration, 
                         max_participants, price_adult, price_child, availability, created_at, updated_at) 
                         VALUES ('$title', '$description', '$location', '$image_url', $duration, 
                         $max_participants, $price_adult, $price_child, $availability, NOW(), NOW())";
        
        if (mysqli_query($conn, $insert_query)) {
            $success_message = "Farm experience created successfully!";
            
            // Clear form data after successful submission
           
    }
}
}


// Get existing farm experiences for reference
$experiences_query = "SELECT id, title FROM farm_experiences ORDER BY title ASC";
$experiences_result = mysqli_query($conn, $experiences_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Farm Experience - Admin Dashboard - AGRIVISTA</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        <?php include "assets/css/dash.css"; ?>
        <?php include "assets/css/experience.css"; ?>
    </style>
</head>
<body>
<div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-leaf"></i>
                    <span>AGRIVISTA</span>
                </div>
            </div>
            
            <nav class="sidebar-menu">
                <a href="dashboard.php" class="menu-item active">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="user.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
                <a href="booking.php" class="menu-item">
                    <i class="fas fa-calendar-check"></i>
                    <span>Bookings</span>
                </a>
                <a href="experiences.php" class="menu-item">
                    <i class="fas fa-tractor"></i>
                    <span>Farm Experiences</span>
                </a>
                <a href="payments.php" class="menu-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Payments</span>
                </a>
                <a href="php" class="menu-item">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports</span>
                </a>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cogs"></i>
                    <span>Settings</span>
                </a>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div class="page-title">Create Farm Experience</div>
                <div class="user-info">
                    <div class="notification">
                        <i class="far fa-bell"></i>
                        <span class="notification-badge">2</span>
                    </div>
                    <div class="user-avatar"><?php echo substr($admin['first_name'], 0, 1); ?></div>
                    <div class="username"><?php echo $admin['first_name'] . ' ' . $admin['last_name']; ?></div>
                </div>
            </div>
            
            <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($error_message)): ?>
            <div class="alert alert-error">
                <?php echo $error_message; ?>
            </div>
            <?php endif; ?>
            
            <!-- Create Experience Form -->
            <div class="form-container">
                <div class="form-title">Add New Farm Experience</div>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
                    <div class="form-subtitle">Basic Information</div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label required">Experience Title</label>
                            <input type="text" name="title" class="form-control" required 
                                   value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>">
                            <p class="input-hint">Enter a descriptive title for the farm experience</p>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label required">Location</label>
                            <input type="text" name="location" class="form-control" required
                                   value="<?php echo isset($_POST['location']) ? htmlspecialchars($_POST['location']) : ''; ?>">
                            <p class="input-hint">Farm name and area, e.g. "Green Valley Farm, Riverside"</p>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label required">Description</label>
                            <textarea name="description" class="form-control" required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                            <p class="input-hint">Provide a detailed description of the experience</p>
                        </div>
                    </div>
                    
                    <div class="form-subtitle">Experience Details</div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label required">Duration (hours)</label>
                            <input type="number" name="duration" class="form-control" step="0.5" min="0.5" max="8" required
                                   value="<?php echo isset($_POST['duration']) ? htmlspecialchars($_POST['duration']) : '2'; ?>">
                            <p class="input-hint">Duration in hours (e.g. 2.5 for 2 hours and 30 minutes)</p>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label required">Maximum Participants</label>
                            <input type="number" name="max_participants" class="form-control" min="1" max="50" required
                                   value="<?php echo isset($_POST['max_participants']) ? htmlspecialchars($_POST['max_participants']) : '10'; ?>">
                            <p class="input-hint">Maximum number of people allowed per session</p>
                        </div>
                    </div>
                    
                    <div class="form-subtitle">Pricing</div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label required">Adult Price ($)</label>
                            <input type="number" name="price_adult" class="form-control" step="0.01" min="0" required
                                   value="<?php echo isset($_POST['price_adult']) ? htmlspecialchars($_POST['price_adult']) : ''; ?>">
                            <p class="input-hint">Price per adult</p>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label required">Child Price ($)</label>
                            <input type="number" name="price_child" class="form-control" step="0.01" min="0" required
                                   value="<?php echo isset($_POST['price_child']) ? htmlspecialchars($_POST['price_child']) : ''; ?>">
                            <p class="input-hint">Price per child (under 12 years)</p>
                        </div>
                    </div>
                    
                    <div class="form-subtitle">Media</div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label required">Experience Image</label>
                            <div class="file-upload">
                                <input type="file" name="image" id="experience-image" class="file-upload-input" accept="image/jpeg, image/png" required>
                                <label for="experience-image" class="file-upload-button">
                                    <i class="fas fa-cloud-upload-alt"></i> Choose Image
                                </label>
                                <div class="file-name" id="file-name">No file chosen</div>
                                <div class="image-preview" id="image-preview">
                                    <img id="preview-img" src="#" alt="Preview">
                                </div>
                            </div>
                            <p class="input-hint">Upload a high-quality image (JPEG, PNG) that represents the experience</p>
                        </div>
                    </div>
                    
                    <div class="form-subtitle">Availability</div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="toggle-switch">
                                <input type="checkbox" name="availability" checked>
                                <span class="slider"></span>
                                <span class="switch-label">Make this experience available for booking</span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="btn-container">
                        <a href="admin_experiences.php" class="btn btn-secondary">Cancel</a>
                        <button type="submit" name="create_experience" class="btn btn-primary">Create Experience</button>
                    </div>
                </form>
            </div>
            
            <!-- Existing Experiences Reference -->
            <div class="form-container table-container">
                <div class="form-title">Existing Farm Experiences</div>
                <p class="input-hint">Reference list of current farm experiences in the system</p>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th width="10%">ID</th>
                            <th width="90%">Title</th>
                            <th width="5%">action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $experiences_result = mysqli_query($conn, "SELECT * FROM farm_experiences");
                        if (mysqli_num_rows($experiences_result) > 0):
                            while ($exp = mysqli_fetch_assoc($experiences_result)):
                        ?>
                        <tr>
                            <td><?php echo $exp['farmid']; ?></td>
                            <td><?php echo htmlspecialchars($exp['title']); ?></td>
                            <td><a href='?delete=<?php echo $exp['farmid']; ?>' class='delete-button'>Delete</a></td>
                        </tr>
                        <?php 
                            endwhile;
                        else:
                        ?>
                        <tr>
                            <td colspan="2">No farm experiences available yet.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        // Image preview functionality
        document.getElementById('experience-image').addEventListener('change', function(e) {
            const fileInput = e.target;
            const fileName = document.getElementById('file-name');
            const imagePreview = document.getElementById('image-preview');
            const previewImg = document.getElementById('preview-img');
            
            if (fileInput.files && fileInput.files[0]) {
                const file = fileInput.files[0];
                fileName.textContent = file.name;
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    imagePreview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                fileName.textContent = 'No file chosen';
                imagePreview.style.display = 'none';
            }
        });
    </script>
</body>
</html>