<?php   
include "config/config.php";

if(isset($_POST['login'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // Validate email format    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format!');</script>";
        exit;
    }

    // Fetch user from database (using prepared statement would be better)
    $sql = "SELECT * FROM customer WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    // Check if user exists
    if(mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_assoc($result);
        if(password_verify($password, $row['password'])){
            // Start a session and store user information
            session_start();
            $_SESSION['user_id'] = $row['customerid'];
            $_SESSION['username'] = $row['username']; 
            
            // Redirect to index.html
            header("Location: cudash.php");
            exit();
        } else {
            echo "<script>alert('Invalid password!');</script>";
        }
    } else {
        echo "<script>alert('No user found with this email!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AGRIVISTA - Login</title>
  <style>
   <?php include "css/login.css"; ?>
  </style>
</head>
<body>
  <div class="container">
    <div class="form-container">
      <div class="leaf leaf-1"></div>
      <div class="leaf leaf-2"></div>
      
      <!-- Login Form -->
      <form method="post" class="login-form" action="">
  <div class="form-title-decoration">
    <i>🌿</i>
    <h1>Welcome Back</h1>
  </div>
  <p style="color: #666; margin-bottom: 30px;">Reconnect with nature and continue your agro journey.</p>
  
  <div class="form-group">
    <span class="icon">📧</span>
    <input name="email" type="email" class="form-control" placeholder="Email Address" required>
  </div>
  
  <div class="form-group">
    <span class="icon">🔒</span>
    <input name="password" type="password" class="form-control" placeholder="Password" required>
  </div>
  
  <div class="checkmark-container" onclick="toggleCheckbox(this)">
    <div class="custom-checkbox"></div>
    <span>Remember me</span>
  </div>
  <div class="action">
    <a href="#" class="forgot-password">Forgot Password?</a>
    <button name="login" type="submit" class="btn">Log In</button>
  </div>
  
  <div class="social-login">
    <p>Or continue with</p>
    <div class="social-icons">
      <div class="social-icon">G</div>
      <div class="social-icon">f</div>
      <div class="social-icon">in</div>
    </div>
  </div>
</form>
    </div>
    
    <div class="image-container">
      <div class="image-overlay">
        <h2>New to Farm Escapes?</h2>
        <p>Sign up and discover unique farm experiences, connect with local farmers, and plan your next agricultural adventure.</p>
        <a href="signup.php" class="switch-btn">Sign Up</a>
      </div>
    </div>
  </div>

  <script>
    function toggleCheckbox(element) {
      const checkbox = element.querySelector('.custom-checkbox');
      checkbox.classList.toggle('checked');
    }
  </script>
</body>
</html>