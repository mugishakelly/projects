<?php
 include "config/config.php";

 $user_id = $_SESSION['user_id'];
 $user_query = "SELECT * FROM customer WHERE customerid = $user_id";
 $user_result = mysqli_query($conn, $user_query);
 $user = mysqli_fetch_assoc($user_result);
 
 // Select all from farm
 $sql = "SELECT * FROM farm_experiences";
 $result = mysqli_query($conn, $sql);
 ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Farm Experience - AGRIVISTA</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        <?php include "css/cudash.css"; ?>
        <?php include "css/booking.css"; ?>
        <?php include "css/farms.css"; ?>
    </style>
</head>
<body>
<div class="dashboard">
    <!-- Sidebar -->
    <div class="sidebar">
      <div class="sidebar-header">
        <div class="logo">AGRIVISTA</div>
        <div class="sidebar-logo-text">Connecting You to Nature</div>
      </div>
      <div class="sidebar-menu">
        <a href="cudash.php" class="menu-item active">
          <i class="fas fa-home"></i> Dashboard
        </a>
        <a href="farms.php" class="menu-item">
          <i class="fas fa-leaf"></i> Farm Experiences
        </a>
        <a href="bookings.php" class="menu-item">
          <i class="fas fa-calendar-alt"></i> My Bookings
        </a>    
        <a href="favorite.php" class="menu-item">
          <i class="fas fa-heart"></i> Favorites
        </a>
        <a href="settings.php" class="menu-item">
          <i class="fas fa-cog"></i> Settings
        </a>
        <a href="help.php" class="menu-item">
          <i class="fas fa-question-circle"></i> Help & Support
        </a>
        <a href="logout.php" class="menu-item">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </div>
    </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div class="page-title">Farm Experience options</div>
                <div class="user-info">
                    <div class="notification">
                        <i class="far fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </div>
                    <div class="user-avatar"><?php echo substr($user['first_name'], 0, 1); ?></div>
                    <div class="username"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></div>
                </div>
            </div>
            
            <?php if (isset($booking_error) && !empty($booking_error)): ?>
            <div class="alert alert-error">
                <?php echo $booking_error; ?>
            </div>
            <?php endif; ?>

                <!-- farm experience options cards -->

                <div class="section-title">
  <i class="fas fa-leaf"></i> Recommended Farm Experiences
</div>
<div class="farm-experiences">
  <?php if(mysqli_num_rows($result) > 0): ?>
    <?php while ($farm = mysqli_fetch_assoc($result)): ?>
      <div class="farm-card">
        <div class="farm-image" style="background-image: url('<?php echo $farm['image_url']; ?>')"></div>
        <div class="farm-details">
          <div class="farm-title"><?php echo $farm['title']; ?></div>
          <div class="farm-location">
            <i class="fas fa-map-marker-alt"></i> <?php echo $farm['location']; ?>
          </div>
          <div class="farm-activities">
            <span class="activity-tag"><?php echo substr($farm['description'], 0, 50) . '...'; ?></span>
          </div>
          <p><?php echo isset($farm['short_description']) ? $farm['short_description'] : substr($farm['description'], 0, 100) . '...'; ?></p>
          <div class="farm-footer">
            <div class="farm-price">$<?php echo $farm['price_adult']; ?> / person</div>
            <button class="book-btn" data-id="<?php echo $farm['farmid']; ?>">Book Now</button>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <p>No farm experiences available at this time.</p>
  <?php endif; ?>
</div>

        




</body>
</html>