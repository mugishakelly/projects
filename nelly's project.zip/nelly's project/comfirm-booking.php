<?php
include "config/config.php";
// session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$customerid = $_SESSION['user_id'];

// Mark booking as complete
if (isset($_GET['complete'])) {
    $bookingid = $_GET['complete'];
    
    // Verify the booking belongs to this customer before updating
    $verify_sql = "SELECT * FROM bookings WHERE bookingid = $bookingid AND customerid = $customerid";
    $verify_result = mysqli_query($conn, $verify_sql);
    
    if (mysqli_num_rows($verify_result) > 0) {
        $sql = "UPDATE bookings SET status = 'Completed', customer_completed = 1 WHERE bookingid = $bookingid";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            echo "<script>alert('Thank you for confirming your visit is complete!');</script>";
            echo "<script>window.location.href='my-bookings.php';</script>";
        } else {
            echo "<script>alert('Error updating booking status.');</script>";
        }
    } else {
        echo "<script>alert('You do not have permission to complete this booking.');</script>";
        echo "<script>window.location.href='my-bookings.php';</script>";
    }
}

// Add review for completed booking
if (isset($_POST['submit_review'])) {
    $bookingid = $_POST['bookingid'];
    $rating = $_POST['rating'];
    $review_text = mysqli_real_escape_string($conn, $_POST['review_text']);
    
    // Verify the booking belongs to this customer
    $verify_sql = "SELECT * FROM bookings WHERE bookingid = $bookingid AND customerid = $customerid";
    $verify_result = mysqli_query($conn, $verify_sql);
    
    if (mysqli_num_rows($verify_result) > 0) {
        // Check if a review already exists
        $check_sql = "SELECT * FROM reviews WHERE bookingid = $bookingid";
        $check_result = mysqli_query($conn, $check_sql);
        
        if (mysqli_num_rows($check_result) > 0) {
            // Update existing review
            $update_sql = "UPDATE reviews SET rating = $rating, review_text = '$review_text', review_date = NOW() WHERE bookingid = $bookingid";
            $update_result = mysqli_query($conn, $update_sql);
            
            if ($update_result) {
                echo "<script>alert('Your review has been updated!');</script>";
            } else {
                echo "<script>alert('Error updating review.');</script>";
            }
        } else {
            // Insert new review
            $insert_sql = "INSERT INTO reviews (bookingid, customerid, rating, review_text, review_date) 
                          VALUES ($bookingid, $customerid, $rating, '$review_text', NOW())";
            $insert_result = mysqli_query($conn, $insert_sql);
            
            if ($insert_result) {
                echo "<script>alert('Thank you for your review!');</script>";
            } else {
                echo "<script>alert('Error submitting review.');</script>";
            }
        }
        
        echo "<script>window.location.href='my-bookings.php';</script>";
    } else {
        echo "<script>alert('You do not have permission to review this booking.');</script>";
        echo "<script>window.location.href='my-bookings.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings - Agro Tourism</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        <?php include "css/cudash.css"; ?>
        <?php include "css/booking.css"; ?>
        <?php include "css/farms.css"; ?>
        <?php include "css/comfirm.css"; ?>
    </style>
</head>
<body>
    <header>
        <div class="container header-container">
            <div class="logo">
                <i class="fas fa-leaf"></i>
                <span>AGRIVISTA</span>
            </div>
            <div class="nav-menu">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="experiences.php"><i class="fas fa-tractor"></i> Experiences</a>
                <a href="my-bookings.php" class="active"><i class="fas fa-calendar-check"></i> My Bookings</a>
                <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <div class="container">
        <h1 class="page-title">My Bookings</h1>
        
        <div class="bookings-container">
            <?php
            // Get all bookings for the current customer
            $sql = "SELECT b.*, e.title, e.image_url 
                   FROM bookings b
                   JOIN farm_experiences e ON b.farmid = e.farmid
                   WHERE b.customerid = $customerid
                   ORDER BY b.booking_datetime DESC";
            
            $result = mysqli_query($conn, $sql);
            
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    // Get review if exists
                    $review_sql = "SELECT * FROM bookings WHERE bookingid = " . $row['bookingid'];
                    $review_result = mysqli_query($conn, $review_sql);
                    $has_review = mysqli_num_rows($review_result) > 0;
                    $review = $has_review ? mysqli_fetch_assoc($review_result) : null;
                    
                    $status_class = "";
                    switch ($row['status']) {
                        case 'Pending':
                            $status_class = "status-pending";
                            break;
                        case 'Confirmed':
                            $status_class = "status-confirmed";
                            break;
                        case 'Completed':
                            $status_class = "status-completed";
                            break;
                        case 'Declined':
                            $status_class = "status-declined";
                            break;
                        default:
                            $status_class = "";
                    }
                    
                    // Format the date
                    $booking_date = date("F j, Y, g:i a", strtotime($row['booking_datetime']));
                    
                    echo '<div class="booking-card">';
                    echo '<div class="booking-header">';
                    echo '<span class="booking-id">Booking #' . $row['bookingid'] . '</span>';
                    echo '<span class="booking-status ' . $status_class . '">' . $row['status'] . '</span>';
                    echo '</div>';
                    
                    echo '<div class="booking-details">';
                    echo '<p><i class="fas fa-calendar"></i> ' . $booking_date . '</p>';
                    echo '<p><i class="fas fa-tractor"></i> ' . $row['title'] . '</p>';
                    echo '<p><i class="fas fa-users"></i> ' . $row['total_participants'] . ' Visitors</p>';
                    echo '<p><i class="fas fa-dollar-sign"></i> Payment: ' . $row['payment_method'] . '</p>';
                    
                    // If booking has been completed and reviewed, show the rating
                    if ($row['status'] == 'Completed' && $has_review) {
                        echo '<p><i class="fas fa-star"></i> Your Rating: ' . $review['rating'] . '/5</p>';
                    }
                    
                    echo '</div>';
                    
                    echo '<div class="booking-actions">';
                    
                    // Different actions based on booking status
                    if ($row['status'] == 'Confirmed') {
                        echo '<a href="?complete=' . $row['bookingid'] . '" class="action-button complete-button">Mark as Completed</a>';
                    } else if ($row['status'] == 'Pending') {
                        echo '<a href="cancel-booking.php?id=' . $row['bookingid'] . '" class="action-button cancel-button">Cancel</a>';
                    }
                    
                    // Show review button for completed bookings
                    if ($row['status'] == 'Completed') {
                        echo '<button class="action-button review-button" onclick="toggleReviewForm(' . $row['bookingid'] . ')">'. ($has_review ? 'Edit Review' : 'Leave a Review') .'</button>';
                    }
                    
                    echo '</div>';
                    
                    // Review form (hidden by default)
                    echo '<div id="review-form-' . $row['bookingid'] . '" class="review-form ' . ($has_review && isset($_GET['edit_review']) && $_GET['edit_review'] == $row['bookingid'] ? 'active' : '') . '">';
                    echo '<form method="POST" action="">';
                    echo '<input type="hidden" name="bookingid" value="' . $row['bookingid'] . '">';
                    
                    echo '<div class="rating">';
                    for ($i = 5; $i >= 1; $i--) {
                        echo '<input type="radio" name="rating" id="star' . $i . '-' . $row['bookingid'] . '" value="' . $i . '" ' . ($has_review && $review['rating'] == $i ? 'checked' : '') . '>';
                        echo '<label for="star' . $i . '-' . $row['bookingid'] . '"></label>';
                    }
                    echo '</div>';
                    
                    echo '<textarea name="review_text" class="review-textarea" placeholder="Share your experience...">' . ($has_review ? $review['review_text'] : '') . '</textarea>';
                    echo '<button type="submit" name="submit_review" class="submit-review">Submit Review</button>';
                    echo '</form>';
                    echo '</div>';
                    
                    echo '</div>'; // End booking-card
                }
            } else {
                // Empty state
                echo '<div class="empty-bookings">';
                echo '<i class="fas fa-calendar-times"></i>';
                echo '<h3>No Bookings Yet</h3>';
                echo '<p>You haven\'t made any bookings yet. Browse our farm experiences and book your first visit!</p>';
                echo '<a href="experiences.php" class="browse-button">Browse Experiences</a>';
                echo '</div>';
            }
            ?>
        </div>
    </div>

    <script>
        function toggleReviewForm(bookingId) {
            const form = document.getElementById('review-form-' + bookingId);
            form.classList.toggle('active');
        }
    </script>
</body>
</html>